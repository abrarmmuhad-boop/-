// تم تثبيت مفتاحك والموديل الجديد هنا
const SAMBANOVA_API_KEY = "4b056c1e-c974-4621-9922-731432a1e865";

let extraFactors = [];

function $(id) { return document.getElementById(id); }

function escapeHtml(str) {
    return String(str ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function safeParseJSON(text) {
    try {
        const s = text.indexOf("{");
        const e = text.lastIndexOf("}");
        if (s === -1 || e === -1) {
            throw new Error("لم يتم العثور على بيانات JSON في الرد.");
        }
        const cleanJson = text.slice(s, e + 1);
        return JSON.parse(cleanJson);
    } catch (err) {
        console.error("خطأ في تحليل النص:", text);
        throw new Error("صيغة الرد من الذكاء الاصطناعي غير مدعومة، جربي مرة أخرى.");
    }
}

function showSection(sectionId) {
    ["homeSection", "coSection", "rumorSection"].forEach(id => {
        $(id).classList.remove("active");
    });
    
    $(sectionId).classList.add("active");
    
    const pills = document.querySelectorAll('.nav-pill');
    pills.forEach(pill => pill.classList.remove('active'));
    
    if (sectionId === "homeSection") {
        pills[0].classList.add("active");
    } else if (sectionId === "rumorSection") {
        pills[1].classList.add("active");
        $("rumorStatus").textContent = "";
        $("rumorStatus").className = "status-msg";
    } else if (sectionId === "coSection") {
        pills[2].classList.add("active");
        $("coStatus").textContent = "";
        $("coStatus").className = "status-msg";
    }
    
    window.scrollTo(0, 0);
}

window.showSection = showSection;

$("co").addEventListener("input", () => {
    $("coVal").textContent = $("co").value;
});

$("motivation").addEventListener("input", () => {
    $("motVal").textContent = $("motivation").value;
});

function renderFactors() {
    const box = $("factorChips");
    box.innerHTML = "";
    
    extraFactors.forEach((f, idx) => {
        const div = document.createElement("div");
        div.className = "chip";
        div.innerHTML = `${escapeHtml(f)} <button type="button">×</button>`;
        div.querySelector("button").onclick = () => {
            extraFactors.splice(idx, 1);
            renderFactors();
        };
        box.appendChild(div);
    });
}

function addFactor() {
    const inp = $("factorInput");
    const v = (inp.value || "").trim();
    if (!v) return;
    
    extraFactors.push(v);
    inp.value = "";
    renderFactors();
}

window.addFactor = addFactor;

function getCheckedTriggers() {
    return Array.from(document.querySelectorAll('input[name="tr"]:checked'))
        .map(x => x.value);
}

function readCOForm() {
    return {
        co_ppm_reading: Number($("co").value),
        age: Number($("age").value),
        daily_cigarette_count: Number($("cigs").value),
        years_smoked: Number($("years").value),
        motivation_level: Number($("motivation").value),
        primary_triggers: getCheckedTriggers(),
        extra_factors: extraFactors,
        symptoms: $("symptoms").value.trim()
    }
}

function showError(statusElement, message, details = "") {
    statusElement.className = "status-msg error";
    statusElement.innerHTML = `
        <div>❌ ${escapeHtml(message)}</div>
        ${details ? `<div class="error-details" style="font-size:12px; margin-top:10px;">${escapeHtml(details)}</div>` : ''}
    `;
}

// الاتصال المحدث بخوادم SambaNova (الموديل الجديد 3.3)
async function callSambaNova(promptText) {
    const url = "https://api.sambanova.ai/v1/chat/completions";

    const body = {
        model: "Meta-Llama-3.3-70B-Instruct", // تم تحديث الموديل هنا
        messages: [{ role: "user", content: promptText }],
        temperature: 0.7, 
        max_tokens: 2000
    };

    try {
        const res = await fetch(url, {
            method: "POST",
            headers: { 
                "Content-Type": "application/json",
                "Authorization": `Bearer ${SAMBANOVA_API_KEY}`
            },
            body: JSON.stringify(body)
        });

        if (!res.ok) {
            const errorText = await res.text();
            console.error('API Error:', res.status, errorText);
            if (res.status === 401) throw new Error("المفتاح غير مصرح به (Unauthorized). تأكدي أن المفتاح فعال.");
            if (res.status === 410) throw new Error("تم تحديث الموديل من قبل المزود. يرجى تعديل اسم الموديل في الكود.");
            if (res.status === 429) throw new Error("ضغط عالي على السيرفر، جربي بعد ثواني.");
            throw new Error(`خطأ في الاتصال بالسيرفر: ${res.status}`);
        }

        const data = await res.json();
        const text = data?.choices?.[0]?.message?.content || "";
            
        if (!text.trim()) {
            throw new Error("رد فارغ من الذكاء الاصطناعي");
        }
        
        return text;
    } catch (error) {
        if (error.message.includes("Failed to fetch")) {
            throw new Error("تعذر الاتصال بالسيرفر (تأكدي من اتصال الإنترنت).");
        }
        throw error;
    }
}

function buildRumorPrompt(claim) {
    return `أنت خبير صحي. قم بتحليل هذه المعلومة الطبية: "${claim}". 
يجب أن يكون ردك بصيغة JSON فقط، بدون أي نصوص أو مقدمات أو علامات Markdown. يجب أن يحتوي الرد على هذه المفاتيح بالضبط:
{
  "verdict": "True أو False أو Misleading أو Unclear",
  "risk_level": "Low أو Moderate أو High",
  "explanation_simple": "شرح واضح ومختصر بالعربي في جملتين",
  "correction": "التصحيح العلمي الدقيق",
  "advice": "نصيحة طبية آمنة",
  "disclaimer": "تنبيه: استشر طبيبك المختص دائماً"
}`;
}

function buildCOPrompt(user) {
    return `أنت طبيب خبير في الإقلاع عن التدخين. حلل حالة هذا المريض:
العمر: ${user.age}، السجائر يومياً: ${user.daily_cigarette_count}، سنوات التدخين: ${user.years_smoked}، المحفزات: ${user.primary_triggers.join(", ")}.
رد بصيغة JSON فقط بدون مقدمات وبدون Markdown:
{
  "risk_level": "Low أو Moderate أو High",
  "verdict_label": "وصف قصير للحالة",
  "summary": "ملخص الحالة",
  "personalized_insights": "تحليل شخصي",
  "recommended_duration_days": 30,
  "quit_day": 14,
  "taper_plan_weeks": [{"week": 1, "target_cigarettes_per_day": 5, "goals": ["هدف"], "actions": ["إجراء"], "tip": "نصيحة"}],
  "trigger_coping_strategies": [{"trigger": "المحفز", "replacement": "البديل", "quick_action": "إجراء سريع"}]
}`;
}

function renderRumorAI(out) {
    $("rumorResultBox").classList.remove("hidden");
    
    const verdictColors = {
        "True": "background: linear-gradient(135deg, #11998e, #38ef7d); color: #0a0e27;",
        "False": "background: linear-gradient(135deg, #ff0844, #ff6b6b); color: white;",
        "Misleading": "background: linear-gradient(135deg, #ff6b6b, #feca57); color: #0a0e27;",
        "Unclear": "background: linear-gradient(135deg, #00d9f5, #a960ee); color: white;"
    };
    $("rumorVerdict").textContent = `الحكم: ${out.verdict || "—"}`;
    $("rumorVerdict").setAttribute('style', verdictColors[out.verdict] || verdictColors["Unclear"]);
    
    const riskColors = {
        "Low": "background: linear-gradient(135deg, #11998e, #38ef7d); color: #0a0e27;",
        "Moderate": "background: linear-gradient(135deg, #ff6b6b, #feca57); color: #0a0e27;",
        "High": "background: linear-gradient(135deg, #ff0844, #ff6b6b); color: white;"
    };
    $("rumorRisk").textContent = `الخطر: ${out.risk_level || "—"}`;
    $("rumorRisk").setAttribute('style', riskColors[out.risk_level] || riskColors["Moderate"]);
    
    $("rumorExplanation").textContent = out.explanation_simple || "";
    $("rumorCorrection").textContent = out.correction || "";
    $("rumorAdvice").textContent = out.advice || "";
    $("rumorRaw").textContent = JSON.stringify(out, null, 2);
}

async function checkRumor() {
    $("rumorStatus").textContent = "";
    $("rumorStatus").className = "status-msg";
    $("rumorResultBox").classList.add("hidden");

    const claim = $("rumorText").value.trim();
    if (!claim) {
        showError($("rumorStatus"), "⚠️ يرجى إدخال المعلومة أولًا");
        return;
    }

    $("rumorStatus").className = "status-msg";
    $("rumorStatus").textContent = "🔄 جاري تحليل المعلومة بالذكاء الاصطناعي...";
    
    try {
        const prompt = buildRumorPrompt(claim);
        const aiResponse = await callSambaNova(prompt);
        const result = safeParseJSON(aiResponse);
        
        renderRumorAI(result);
        $("rumorStatus").className = "status-msg success";
        $("rumorStatus").textContent = "✅ تم التحقق من المعلومة بنجاح!";
    } catch (error) {
        showError($("rumorStatus"), "حدث خطأ أثناء التحليل", error.message);
    }
}

function renderCOAI(out) {
    $("coResultBox").classList.remove("hidden");

    const riskColors = {
        "Low": "background: linear-gradient(135deg, #11998e, #38ef7d); color: #0a0e27;",
        "Moderate": "background: linear-gradient(135deg, #ff6b6b, #feca57); color: #0a0e27;",
        "High": "background: linear-gradient(135deg, #ff0844, #ff6b6b); color: white;"
    };
    $("coRiskBadge").textContent = `الخطورة: ${out.risk_level || "—"}`;
    $("coRiskBadge").setAttribute('style', riskColors[out.risk_level] || riskColors["Moderate"]);
    
    $("coVerdictBadge").textContent = `الحالة: ${out.verdict_label || "—"}`;
    $("coVerdictBadge").setAttribute('style', 'background: linear-gradient(135deg, #00f5a0, #00d9f5); color: #0a0e27;');

    $("coSummary").textContent = out.summary || "";
    $("coInsight").textContent = out.personalized_insights || "";
    $("coStrategy").textContent = `المدة المقترحة: ${out.recommended_duration_days ?? "—"} يوم • يوم الإقلاع: اليوم ${out.quit_day ?? "—"}`;

    const plan = $("coPlanGrid");
    plan.innerHTML = "";
    (out.taper_plan_weeks || []).forEach(w => {
        const div = document.createElement("div");
        div.className = "dayCard";
        div.innerHTML = `
            <h4>الأسبوع ${escapeHtml(w.week)} — الهدف: ${escapeHtml(w.target_cigarettes_per_day)} سيجارة/يوم</h4>
            <div><strong>الأهداف:</strong><ul>${(w.goals || []).map(g => `<li>${escapeHtml(g)}</li>`).join("")}</ul></div>
            <div><strong>الإجراءات:</strong><ul>${(w.actions || []).map(a => `<li>${escapeHtml(a)}</li>`).join("")}</ul></div>
            <p class="tip"><strong>💡 نصيحة:</strong> ${escapeHtml(w.tip || "")}</p>
        `;
        plan.appendChild(div);
    });

    const tg = $("coTriggerGrid");
    tg.innerHTML = "";
    (out.trigger_coping_strategies || []).forEach(t => {
        const div = document.createElement("div");
        div.className = "trCard";
        div.innerHTML = `
            <p><strong>🎯 المحفز:</strong> ${escapeHtml(t.trigger)}</p>
            <p><strong>🔄 البديل:</strong> ${escapeHtml(t.replacement)}</p>
            <p><strong>⚡ إجراء سريع:</strong> ${escapeHtml(t.quick_action)}</p>
        `;
        tg.appendChild(div);
    });

    $("coRaw").textContent = JSON.stringify(out, null, 2);
}

async function analyzeCO() {
    $("coStatus").textContent = "";
    $("coStatus").className = "status-msg";
    $("coResultBox").classList.add("hidden");

    const user = readCOForm();
    if (user.age < 10 || user.age > 90) {
        showError($("coStatus"), "⚠️ يرجى إدخال عمر صحيح (10-90)");
        return;
    }

    $("coStatus").className = "status-msg";
    $("coStatus").textContent = "🔄 جاري بناء الخطة المخصصة بالذكاء الاصطناعي...";

    try {
        const prompt = buildCOPrompt(user);
        const aiResponse = await callSambaNova(prompt);
        const result = safeParseJSON(aiResponse);
        
        renderCOAI(result);
        $("coStatus").className = "status-msg success";
        $("coStatus").textContent = "✅ تم بناء خطتك المخصصة بنجاح!";
    } catch (error) {
        showError($("coStatus"), "حدث خطأ أثناء تحليل البيانات", error.message);
    }
}

window.checkRumor = checkRumor;
window.analyzeCO = analyzeCO;

document.addEventListener('DOMContentLoaded', () => {
    showSection("homeSection");
});